const namespace = {
  parentPropName: '_imgPreviewLists'
}

export default namespace
