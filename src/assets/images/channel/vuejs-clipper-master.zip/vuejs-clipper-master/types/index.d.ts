export interface clipperBasic {}
export interface clipperFixed {}
export interface clipperUpload {}
export interface clipperPreview {}
export interface clipperRange {}